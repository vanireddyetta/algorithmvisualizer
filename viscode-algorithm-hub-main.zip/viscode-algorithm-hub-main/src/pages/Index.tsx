import React from 'react';
import { Button } from '@/components/ui/button';
import AlgorithmCard from '@/components/AlgorithmCard';
import { BarChart, Route, Search, TreePine, User, LogOut } from 'lucide-react';

const Index = () => {
  const algorithmCategories = [
    {
      title: 'Sorting Algorithms',
      description: 'Visualize how different sorting algorithms work step by step',
      complexity: 'O(n²) to O(n log n)',
      icon: BarChart,
      difficulty: 'Easy' as const,
      onClick: () => window.location.href = '/sorting'
    },
    {
      title: 'Search Algorithms',
      description: 'Learn how linear and binary search algorithms find elements',
      complexity: 'O(1) to O(n)',
      icon: Search,
      difficulty: 'Easy' as const,
      onClick: () => window.location.href = '/search'
    },
    {
      title: 'Pathfinding Algorithms',
      description: 'See how algorithms find the shortest path between two points',
      complexity: 'O(V + E) to O(V²)',
      icon: Route,
      difficulty: 'Medium' as const,
      onClick: () => console.log('Pathfinding coming soon!')
    },
    {
      title: 'Tree Algorithms',
      description: 'Explore tree traversal and balancing algorithms',
      complexity: 'O(log n) to O(n)',
      icon: TreePine,
      difficulty: 'Hard' as const,
      onClick: () => console.log('Tree algorithms coming soon!')
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold text-gray-900">Algorithm Visualizer</h1>
              <p className="text-gray-600">Learn algorithms through interactive visualizations</p>
            </div>
            <div className="flex items-center space-x-4">
              <Button variant="outline" onClick={() => window.location.href = '/login'}>
                <User className="h-4 w-4 mr-2" />
                Profile
              </Button>
              <Button variant="ghost" onClick={() => window.location.href = '/login'}>
                <LogOut className="h-4 w-4 mr-2" />
                Logout
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-12 px-6">
        <div className="max-w-7xl mx-auto text-center">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">
            Master Algorithms Through Visualization
          </h2>
          <p className="text-xl text-gray-700 mb-8 max-w-3xl mx-auto">
            Understand complex algorithms with step-by-step visual explanations. 
            See how sorting, searching, and pathfinding algorithms work in real-time.
          </p>
          <Button size="lg" className="bg-blue-600 hover:bg-blue-700">
            Start Learning
          </Button>
        </div>
      </section>

      {/* Algorithm Categories */}
      <section className="py-12 px-6">
        <div className="max-w-7xl mx-auto">
          <h3 className="text-2xl font-bold text-gray-900 mb-8 text-center">
            Choose an Algorithm Category
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {algorithmCategories.map((category, index) => (
              <AlgorithmCard
                key={index}
                title={category.title}
                description={category.description}
                complexity={category.complexity}
                icon={category.icon}
                difficulty={category.difficulty}
                onClick={category.onClick}
              />
            ))}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-12 px-6 bg-white">
        <div className="max-w-7xl mx-auto">
          <h3 className="text-2xl font-bold text-gray-900 mb-8 text-center">
            Why Use Algorithm Visualizer?
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="bg-blue-100 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                <BarChart className="h-8 w-8 text-blue-600" />
              </div>
              <h4 className="text-lg font-semibold mb-2">Interactive Visualizations</h4>
              <p className="text-gray-600">
                Watch algorithms come to life with step-by-step animations and controls
              </p>
            </div>
            <div className="text-center">
              <div className="bg-green-100 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                <Search className="h-8 w-8 text-green-600" />
              </div>
              <h4 className="text-lg font-semibold mb-2">Learn by Doing</h4>
              <p className="text-gray-600">
                Adjust parameters and see how they affect algorithm performance
              </p>
            </div>
            <div className="text-center">
              <div className="bg-purple-100 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                <TreePine className="h-8 w-8 text-purple-600" />
              </div>
              <h4 className="text-lg font-semibold mb-2">Comprehensive Coverage</h4>
              <p className="text-gray-600">
                From basic sorting to advanced graph algorithms, we cover it all
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-8 px-6">
        <div className="max-w-7xl mx-auto text-center">
          <p className="text-gray-400">
            © 2024 Algorithm Visualizer. Built to make learning algorithms fun and interactive.
          </p>
        </div>
      </footer>
    </div>
  );
};

export default Index;


import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { ArrowLeft } from 'lucide-react';
import SearchVisualizer from '@/components/SearchVisualizer';
import SearchProblemInput from '@/components/SearchProblemInput';
import SearchAlgorithmExplanation from '@/components/SearchAlgorithmExplanation';

const SearchPage = () => {
  const [selectedAlgorithm, setSelectedAlgorithm] = useState<'linear' | 'binary'>('linear');
  const [currentArray, setCurrentArray] = useState<number[]>([]);
  const [targetValue, setTargetValue] = useState<number | null>(null);
  const [problemDescription, setProblemDescription] = useState<string>('');
  const [currentStep, setCurrentStep] = useState<string>('');

  const algorithms = [
    { key: 'linear' as const, name: 'Linear Search', complexity: 'O(n)' },
    { key: 'binary' as const, name: 'Binary Search', complexity: 'O(log n)' },
  ];

  const handleSearchSubmit = (array: number[], target: number, description: string) => {
    setCurrentArray(array);
    setTargetValue(target);
    setProblemDescription(description);
    setCurrentStep('');
  };

  const handleStepChange = (step: string) => {
    setCurrentStep(step);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-emerald-100 p-6">
      <div className="max-w-7xl mx-auto">
        <div className="mb-6">
          <Button variant="outline" onClick={() => window.history.back()}>
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Home
          </Button>
        </div>

        <div className="mb-6">
          <h1 className="text-3xl font-bold text-gray-900 mb-4">Search Algorithms Visualizer</h1>
          <p className="text-gray-600 mb-4">
            Choose a search algorithm, input your data and target value, and watch how the algorithm finds the element step by step.
          </p>
          <div className="flex flex-wrap gap-2">
            {algorithms.map((algo) => (
              <Button
                key={algo.key}
                onClick={() => setSelectedAlgorithm(algo.key)}
                variant={selectedAlgorithm === algo.key ? "default" : "outline"}
                className="mb-2"
              >
                {algo.name} ({algo.complexity})
              </Button>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 space-y-6">
            <SearchProblemInput 
              onSearchSubmit={handleSearchSubmit}
              algorithm={selectedAlgorithm}
            />
            
            <SearchVisualizer 
              algorithm={selectedAlgorithm}
              inputArray={currentArray}
              targetValue={targetValue}
              problemDescription={problemDescription}
              onStepChange={handleStepChange}
            />
          </div>

          <div className="lg:col-span-1">
            <SearchAlgorithmExplanation
              algorithm={selectedAlgorithm}
              problemDescription={problemDescription}
              currentStep={currentStep}
            />
          </div>
        </div>
      </div>
    </div>
  );
};

export default SearchPage;

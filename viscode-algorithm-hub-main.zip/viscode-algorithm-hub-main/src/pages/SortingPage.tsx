
import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { ArrowLeft } from 'lucide-react';
import SortingVisualizer from '@/components/SortingVisualizer';
import ProblemInput from '@/components/ProblemInput';
import AlgorithmExplanation from '@/components/AlgorithmExplanation';

const SortingPage = () => {
  const [selectedAlgorithm, setSelectedAlgorithm] = useState<'bubble' | 'quick' | 'merge'>('bubble');
  const [currentArray, setCurrentArray] = useState<number[]>([]);
  const [problemDescription, setProblemDescription] = useState<string>('');
  const [currentStep, setCurrentStep] = useState<string>('');

  const algorithms = [
    { key: 'bubble' as const, name: 'Bubble Sort', complexity: 'O(n²)' },
    { key: 'quick' as const, name: 'Quick Sort', complexity: 'O(n log n)' },
    { key: 'merge' as const, name: 'Merge Sort', complexity: 'O(n log n)' },
  ];

  const handleArraySubmit = (array: number[], description: string) => {
    setCurrentArray(array);
    setProblemDescription(description);
    setCurrentStep('');
  };

  const handleStepChange = (step: string) => {
    setCurrentStep(step);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-6">
      <div className="max-w-7xl mx-auto">
        <div className="mb-6">
          <Button variant="outline" onClick={() => window.history.back()}>
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Home
          </Button>
        </div>

        <div className="mb-6">
          <h1 className="text-3xl font-bold text-gray-900 mb-4">Sorting Algorithms Visualizer</h1>
          <p className="text-gray-600 mb-4">
            Choose a sorting algorithm, input your own problem or use examples, and watch how the algorithm solves it step by step.
          </p>
          <div className="flex flex-wrap gap-2">
            {algorithms.map((algo) => (
              <Button
                key={algo.key}
                onClick={() => setSelectedAlgorithm(algo.key)}
                variant={selectedAlgorithm === algo.key ? "default" : "outline"}
                className="mb-2"
              >
                {algo.name} ({algo.complexity})
              </Button>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left Column - Problem Input & Visualization */}
          <div className="lg:col-span-2 space-y-6">
            <ProblemInput 
              onArraySubmit={handleArraySubmit}
              algorithm={selectedAlgorithm}
            />
            
            <SortingVisualizer 
              algorithm={selectedAlgorithm}
              inputArray={currentArray}
              problemDescription={problemDescription}
              onStepChange={handleStepChange}
            />
          </div>

          {/* Right Column - Algorithm Explanation */}
          <div className="lg:col-span-1">
            <AlgorithmExplanation
              algorithm={selectedAlgorithm}
              problemDescription={problemDescription}
              currentStep={currentStep}
            />
          </div>
        </div>
      </div>
    </div>
  );
};

export default SortingPage;


import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { BookOpen, Clock, Zap, Target, List } from 'lucide-react';

interface AlgorithmExplanationProps {
  algorithm: 'bubble' | 'quick' | 'merge';
  problemDescription?: string;
  currentStep?: string;
}

const AlgorithmExplanation: React.FC<AlgorithmExplanationProps> = ({ 
  algorithm, 
  problemDescription,
  currentStep 
}) => {
  const algorithmDetails = {
    bubble: {
      name: 'Bubble Sort',
      description: 'Bubble Sort works by repeatedly comparing adjacent elements and swapping them if they are in the wrong order. It "bubbles" the largest elements to the end of the array.',
      timeComplexity: { best: 'O(n)', average: 'O(n²)', worst: 'O(n²)' },
      spaceComplexity: 'O(1)',
      stability: 'Stable',
      algorithmSteps: [
        'Step 1: Start at the beginning of the array (index 0)',
        'Step 2: Compare current element with the next element',
        'Step 3: If current > next, swap them',
        'Step 4: Move to the next pair of adjacent elements',
        'Step 5: Continue until end of unsorted portion',
        'Step 6: Repeat process, excluding last sorted element',
        'Step 7: Stop when no swaps are made in a complete pass'
      ],
      howItWorks: [
        '1. Start at the beginning of the array',
        '2. Compare each pair of adjacent elements',
        '3. If they are in the wrong order, swap them',
        '4. Continue until the end of the array',
        '5. Repeat the process, but ignore the last sorted element',
        '6. Continue until no more swaps are needed'
      ],
      realWorldUse: 'Educational purposes, small datasets where simplicity is more important than efficiency.',
      pros: ['Simple to understand and implement', 'Stable sorting algorithm', 'Works in-place'],
      cons: ['Very inefficient for large datasets', 'Many unnecessary comparisons']
    },
    quick: {
      name: 'Quick Sort',
      description: 'Quick Sort uses a divide-and-conquer approach. It picks a "pivot" element and partitions the array around it, then recursively sorts the sub-arrays.',
      timeComplexity: { best: 'O(n log n)', average: 'O(n log n)', worst: 'O(n²)' },
      spaceComplexity: 'O(log n)',
      stability: 'Unstable',
      algorithmSteps: [
        'Step 1: Choose a pivot element (usually last element)',
        'Step 2: Initialize partition index i = low - 1',
        'Step 3: For j = low to high-1, compare arr[j] with pivot',
        'Step 4: If arr[j] < pivot, increment i and swap arr[i] with arr[j]',
        'Step 5: After loop, swap arr[i+1] with pivot',
        'Step 6: Recursively sort left subarray (low to i)',
        'Step 7: Recursively sort right subarray (i+2 to high)'
      ],
      howItWorks: [
        '1. Choose a pivot element from the array',
        '2. Partition: rearrange array so elements smaller than pivot come before it',
        '3. Elements greater than pivot come after it',
        '4. Recursively apply Quick Sort to sub-arrays',
        '5. Combine the results'
      ],
      realWorldUse: 'General purpose sorting, system libraries, databases.',
      pros: ['Very efficient on average', 'In-place sorting', 'Cache-efficient'],
      cons: ['Worst-case O(n²) performance', 'Not stable', 'Can cause stack overflow on very large inputs']
    },
    merge: {
      name: 'Merge Sort',
      description: 'Merge Sort uses divide-and-conquer by dividing the array into halves, sorting them separately, then merging the sorted halves back together.',
      timeComplexity: { best: 'O(n log n)', average: 'O(n log n)', worst: 'O(n log n)' },
      spaceComplexity: 'O(n)',
      stability: 'Stable',
      algorithmSteps: [
        'Step 1: If array length ≤ 1, return (base case)',
        'Step 2: Find middle point: mid = (left + right) / 2',
        'Step 3: Recursively sort left half: mergeSort(left, mid)',
        'Step 4: Recursively sort right half: mergeSort(mid+1, right)',
        'Step 5: Create temporary arrays for left and right halves',
        'Step 6: Compare elements from both halves, pick smaller one',
        'Step 7: Copy remaining elements from both halves'
      ],
      howItWorks: [
        '1. Divide the array into two halves',
        '2. Recursively sort both halves',
        '3. Merge the two sorted halves back together',
        '4. Compare elements from each half and take the smaller one',
        '5. Continue until all elements are merged'
      ],
      realWorldUse: 'External sorting, when stability is required, guaranteed O(n log n) performance needed.',
      pros: ['Guaranteed O(n log n) performance', 'Stable sorting', 'Predictable performance'],
      cons: ['Requires additional memory', 'Slower than Quick Sort in practice for smaller arrays']
    }
  };

  const details = algorithmDetails[algorithm];

  const getCurrentAlgorithmStep = (currentStep: string) => {
    if (!currentStep) return null;
    
    // Try to match the current step with algorithm steps
    const stepNumber = details.algorithmSteps.findIndex(step => 
      currentStep.toLowerCase().includes('pass') ||
      currentStep.toLowerCase().includes('comparing') ||
      currentStep.toLowerCase().includes('swap') ||
      currentStep.toLowerCase().includes('pivot') ||
      currentStep.toLowerCase().includes('dividing') ||
      currentStep.toLowerCase().includes('merging')
    );
    
    if (stepNumber !== -1) {
      return stepNumber;
    }
    return null;
  };

  const currentAlgorithmStep = currentStep ? getCurrentAlgorithmStep(currentStep) : null;

  return (
    <div className="space-y-4">
      {problemDescription && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Target className="h-5 w-5" />
              Current Problem
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-gray-700">{problemDescription}</p>
            {currentStep && (
              <div className="mt-3 p-3 bg-blue-50 rounded-lg">
                <p className="text-sm font-medium text-blue-800">Current Step:</p>
                <p className="text-blue-700">{currentStep}</p>
              </div>
            )}
          </CardContent>
        </Card>
      )}

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <List className="h-5 w-5" />
            Algorithm Steps
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            {details.algorithmSteps.map((step, index) => (
              <div 
                key={index} 
                className={`p-2 rounded-lg border-l-4 ${
                  currentAlgorithmStep === index 
                    ? 'bg-blue-50 border-blue-500 text-blue-800' 
                    : 'bg-gray-50 border-gray-300 text-gray-700'
                }`}
              >
                <p className="text-sm font-medium">{step}</p>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <BookOpen className="h-5 w-5" />
            {details.name} Algorithm
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <p className="text-gray-700">{details.description}</p>
          
          <div>
            <h4 className="font-semibold mb-2 flex items-center gap-2">
              <Clock className="h-4 w-4" />
              Performance Characteristics
            </h4>
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <span className="font-medium">Time Complexity:</span>
                <div className="ml-2">
                  <div>Best: <Badge variant="outline">{details.timeComplexity.best}</Badge></div>
                  <div>Average: <Badge variant="outline">{details.timeComplexity.average}</Badge></div>
                  <div>Worst: <Badge variant="outline">{details.timeComplexity.worst}</Badge></div>
                </div>
              </div>
              <div>
                <div><span className="font-medium">Space:</span> <Badge variant="outline">{details.spaceComplexity}</Badge></div>
                <div><span className="font-medium">Stability:</span> <Badge variant={details.stability === 'Stable' ? 'default' : 'secondary'}>{details.stability}</Badge></div>
              </div>
            </div>
          </div>

          <div>
            <h4 className="font-semibold mb-2 flex items-center gap-2">
              <Zap className="h-4 w-4" />
              How It Works
            </h4>
            <ol className="list-decimal list-inside space-y-1 text-sm text-gray-700">
              {details.howItWorks.map((step, index) => (
                <li key={index}>{step}</li>
              ))}
            </ol>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <h4 className="font-semibold mb-2 text-green-700">Advantages</h4>
              <ul className="list-disc list-inside space-y-1 text-sm text-gray-700">
                {details.pros.map((pro, index) => (
                  <li key={index}>{pro}</li>
                ))}
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-2 text-red-700">Disadvantages</h4>
              <ul className="list-disc list-inside space-y-1 text-sm text-gray-700">
                {details.cons.map((con, index) => (
                  <li key={index}>{con}</li>
                ))}
              </ul>
            </div>
          </div>

          <div>
            <h4 className="font-semibold mb-2">Real-World Applications</h4>
            <p className="text-sm text-gray-700">{details.realWorldUse}</p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default AlgorithmExplanation;

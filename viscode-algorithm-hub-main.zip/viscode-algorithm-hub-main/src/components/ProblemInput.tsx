
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { RefreshCw, Play } from 'lucide-react';

interface ProblemInputProps {
  onArraySubmit: (array: number[], problemDescription: string) => void;
  algorithm: string;
}

const ProblemInput: React.FC<ProblemInputProps> = ({ onArraySubmit, algorithm }) => {
  const [inputMethod, setInputMethod] = useState<'example' | 'custom'>('example');
  const [customInput, setCustomInput] = useState('');
  const [selectedExample, setSelectedExample] = useState('');

  const examples = {
    bubble: [
      {
        name: 'Student Grades',
        array: [45, 78, 23, 89, 56, 67, 34, 91],
        description: 'Sort student grades from lowest to highest to see class performance distribution.'
      },
      {
        name: 'Product Prices',
        array: [299, 149, 599, 89, 199, 399, 49],
        description: 'Arrange product prices to help customers find items within their budget.'
      },
      {
        name: 'Age Groups',
        array: [25, 18, 45, 32, 67, 29, 51, 38],
        description: 'Sort ages to analyze demographic distribution in a survey.'
      }
    ],
    quick: [
      {
        name: 'Server Response Times',
        array: [120, 45, 230, 67, 189, 34, 156, 78, 203],
        description: 'Sort server response times (ms) to identify performance bottlenecks.'
      },
      {
        name: 'File Sizes',
        array: [1024, 256, 2048, 512, 128, 4096, 64],
        description: 'Organize file sizes (KB) to optimize storage management.'
      }
    ],
    merge: [
      {
        name: 'Stock Prices',
        array: [150, 120, 180, 90, 200, 110, 170, 140],
        description: 'Sort stock prices to analyze market trends and investment opportunities.'
      },
      {
        name: 'Temperature Data',
        array: [22, 18, 25, 15, 28, 20, 24, 16],
        description: 'Sort temperature readings to identify climate patterns.'
      }
    ]
  };

  const currentExamples = examples[algorithm as keyof typeof examples] || examples.bubble;

  const generateRandomArray = () => {
    const array = Array.from({ length: 8 }, () => Math.floor(Math.random() * 200) + 10);
    const description = 'Random numbers for algorithm demonstration - observe how the sorting process works step by step.';
    onArraySubmit(array, description);
  };

  const handleExampleSelect = (exampleName: string) => {
    setSelectedExample(exampleName);
    const example = currentExamples.find(ex => ex.name === exampleName);
    if (example) {
      onArraySubmit(example.array, example.description);
    }
  };

  const handleCustomSubmit = () => {
    const numbers = customInput
      .split(/[,\s]+/)
      .map(str => parseInt(str.trim()))
      .filter(num => !isNaN(num) && num > 0);
    
    if (numbers.length > 0) {
      const description = `Custom input: ${numbers.join(', ')} - Watch how ${algorithm} sort processes your data.`;
      onArraySubmit(numbers, description);
    }
  };

  return (
    <Card className="mb-6">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Play className="h-5 w-5" />
          Problem Setup
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div className="flex gap-2">
            <Button
              variant={inputMethod === 'example' ? 'default' : 'outline'}
              onClick={() => setInputMethod('example')}
              size="sm"
            >
              Use Example
            </Button>
            <Button
              variant={inputMethod === 'custom' ? 'default' : 'outline'}
              onClick={() => setInputMethod('custom')}
              size="sm"
            >
              Custom Input
            </Button>
            <Button
              variant="outline"
              onClick={generateRandomArray}
              size="sm"
            >
              <RefreshCw className="h-4 w-4 mr-2" />
              Random
            </Button>
          </div>

          {inputMethod === 'example' ? (
            <div>
              <label className="block text-sm font-medium mb-2">Choose a real-world example:</label>
              <Select value={selectedExample} onValueChange={handleExampleSelect}>
                <SelectTrigger>
                  <SelectValue placeholder="Select an example problem..." />
                </SelectTrigger>
                <SelectContent>
                  {currentExamples.map((example) => (
                    <SelectItem key={example.name} value={example.name}>
                      {example.name} - [{example.array.join(', ')}]
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          ) : (
            <div>
              <label className="block text-sm font-medium mb-2">
                Enter your numbers (comma or space separated):
              </label>
              <Textarea
                value={customInput}
                onChange={(e) => setCustomInput(e.target.value)}
                placeholder="e.g., 45, 23, 67, 12, 89, 34"
                className="mb-2"
              />
              <Button onClick={handleCustomSubmit} disabled={!customInput.trim()}>
                Use These Numbers
              </Button>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
};

export default ProblemInput;


import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { BookOpen, Clock, Zap, Target } from 'lucide-react';

interface SearchAlgorithmExplanationProps {
  algorithm: 'linear' | 'binary';
  problemDescription?: string;
  currentStep?: string;
}

const SearchAlgorithmExplanation: React.FC<SearchAlgorithmExplanationProps> = ({ 
  algorithm, 
  problemDescription,
  currentStep 
}) => {
  const algorithmDetails = {
    linear: {
      name: 'Linear Search',
      description: 'Linear Search examines each element in the array sequentially from the beginning until the target element is found or the end is reached.',
      timeComplexity: { best: 'O(1)', average: 'O(n)', worst: 'O(n)' },
      spaceComplexity: 'O(1)',
      howItWorks: [
        '1. Start at the first element of the array',
        '2. Compare the current element with the target',
        '3. If they match, return the current index',
        '4. If not, move to the next element',
        '5. Repeat until target is found or array ends',
        '6. Return -1 if target is not found'
      ],
      realWorldUse: 'Small datasets, unsorted data, when simplicity is preferred over efficiency.',
      pros: ['Works on unsorted data', 'Simple to implement', 'No preprocessing required'],
      cons: ['Inefficient for large datasets', 'Always checks elements sequentially']
    },
    binary: {
      name: 'Binary Search',
      description: 'Binary Search efficiently finds a target element in a sorted array by repeatedly dividing the search interval in half.',
      timeComplexity: { best: 'O(1)', average: 'O(log n)', worst: 'O(log n)' },
      spaceComplexity: 'O(1)',
      howItWorks: [
        '1. Start with the entire sorted array',
        '2. Compare target with the middle element',
        '3. If they match, return the middle index',
        '4. If target is smaller, search the left half',
        '5. If target is larger, search the right half',
        '6. Repeat until target is found or search space is empty'
      ],
      realWorldUse: 'Large sorted datasets, databases, dictionaries, phone books.',
      pros: ['Very efficient O(log n)', 'Eliminates half the search space each step'],
      cons: ['Requires sorted data', 'More complex than linear search']
    }
  };

  const details = algorithmDetails[algorithm];

  return (
    <div className="space-y-4">
      {problemDescription && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Target className="h-5 w-5" />
              Current Search Problem
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-gray-700">{problemDescription}</p>
            {currentStep && (
              <div className="mt-3 p-3 bg-blue-50 rounded-lg">
                <p className="text-sm font-medium text-blue-800">Current Step:</p>
                <p className="text-blue-700">{currentStep}</p>
              </div>
            )}
          </CardContent>
        </Card>
      )}

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <BookOpen className="h-5 w-5" />
            {details.name} Algorithm
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <p className="text-gray-700">{details.description}</p>
          
          <div>
            <h4 className="font-semibold mb-2 flex items-center gap-2">
              <Clock className="h-4 w-4" />
              Performance Characteristics
            </h4>
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <span className="font-medium">Time Complexity:</span>
                <div className="ml-2">
                  <div>Best: <Badge variant="outline">{details.timeComplexity.best}</Badge></div>
                  <div>Average: <Badge variant="outline">{details.timeComplexity.average}</Badge></div>
                  <div>Worst: <Badge variant="outline">{details.timeComplexity.worst}</Badge></div>
                </div>
              </div>
              <div>
                <div><span className="font-medium">Space:</span> <Badge variant="outline">{details.spaceComplexity}</Badge></div>
              </div>
            </div>
          </div>

          <div>
            <h4 className="font-semibold mb-2 flex items-center gap-2">
              <Zap className="h-4 w-4" />
              How It Works
            </h4>
            <ol className="list-decimal list-inside space-y-1 text-sm text-gray-700">
              {details.howItWorks.map((step, index) => (
                <li key={index}>{step}</li>
              ))}
            </ol>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <h4 className="font-semibold mb-2 text-green-700">Advantages</h4>
              <ul className="list-disc list-inside space-y-1 text-sm text-gray-700">
                {details.pros.map((pro, index) => (
                  <li key={index}>{pro}</li>
                ))}
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-2 text-red-700">Disadvantages</h4>
              <ul className="list-disc list-inside space-y-1 text-sm text-gray-700">
                {details.cons.map((con, index) => (
                  <li key={index}>{con}</li>
                ))}
              </ul>
            </div>
          </div>

          <div>
            <h4 className="font-semibold mb-2">Real-World Applications</h4>
            <p className="text-sm text-gray-700">{details.realWorldUse}</p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default SearchAlgorithmExplanation;

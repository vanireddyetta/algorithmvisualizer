
import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Slider } from '@/components/ui/slider';
import { Play, Pause, RotateCcw } from 'lucide-react';

interface SearchVisualizerProps {
  algorithm: 'linear' | 'binary';
  inputArray?: number[];
  targetValue?: number | null;
  problemDescription?: string;
  onStepChange?: (step: string) => void;
}

const SearchVisualizer: React.FC<SearchVisualizerProps> = ({ 
  algorithm, 
  inputArray,
  targetValue,
  problemDescription,
  onStepChange 
}) => {
  const [array, setArray] = useState<number[]>([]);
  const [target, setTarget] = useState<number | null>(null);
  const [searching, setSearching] = useState(false);
  const [speed, setSpeed] = useState([50]);
  const [currentIndex, setCurrentIndex] = useState<number | null>(null);
  const [searchBounds, setSearchBounds] = useState<{left: number, right: number} | null>(null);
  const [found, setFound] = useState<number | null>(null);
  const [currentStep, setCurrentStep] = useState('');
  const [comparisonCount, setComparisonCount] = useState(0);

  useEffect(() => {
    if (inputArray && inputArray.length > 0 && targetValue !== null) {
      let sortedArray = [...inputArray];
      if (algorithm === 'binary') {
        sortedArray.sort((a, b) => a - b);
      }
      setArray(sortedArray);
      setTarget(targetValue);
      setCurrentIndex(null);
      setSearchBounds(null);
      setFound(null);
      setSearching(false);
      setComparisonCount(0);
      updateStep(`Array loaded. Target: ${targetValue}. Ready to search!`);
    }
  }, [inputArray, targetValue, algorithm]);

  const updateStep = (step: string) => {
    setCurrentStep(step);
    onStepChange?.(step);
  };

  const sleep = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

  const linearSearch = async () => {
    if (target === null) return;
    
    updateStep('Starting Linear Search - checking each element one by one');
    let comparisons = 0;
    
    for (let i = 0; i < array.length; i++) {
      if (!searching) return;
      
      setCurrentIndex(i);
      comparisons++;
      setComparisonCount(comparisons);
      updateStep(`Checking index ${i}: ${array[i]} === ${target}?`);
      await sleep(101 - speed[0]);
      
      if (array[i] === target) {
        setFound(i);
        updateStep(`Found target ${target} at index ${i}! Search complete in ${comparisons} comparisons.`);
        return;
      } else {
        updateStep(`${array[i]} ≠ ${target}, continue searching...`);
      }
    }
    
    setCurrentIndex(null);
    updateStep(`Target ${target} not found in the array after ${comparisons} comparisons.`);
  };

  const binarySearch = async () => {
    if (target === null) return;
    
    updateStep('Starting Binary Search - dividing search space in half each time');
    let left = 0;
    let right = array.length - 1;
    let comparisons = 0;
    
    while (left <= right && searching) {
      const mid = Math.floor((left + right) / 2);
      setCurrentIndex(mid);
      setSearchBounds({left, right});
      comparisons++;
      setComparisonCount(comparisons);
      
      updateStep(`Searching in range [${left}, ${right}]. Checking middle index ${mid}: ${array[mid]} === ${target}?`);
      await sleep(101 - speed[0]);
      
      if (array[mid] === target) {
        setFound(mid);
        updateStep(`Found target ${target} at index ${mid}! Search complete in ${comparisons} comparisons.`);
        return;
      } else if (array[mid] < target) {
        updateStep(`${array[mid]} < ${target}, search right half`);
        left = mid + 1;
      } else {
        updateStep(`${array[mid]} > ${target}, search left half`);
        right = mid - 1;
      }
      await sleep(101 - speed[0]);
    }
    
    setCurrentIndex(null);
    setSearchBounds(null);
    updateStep(`Target ${target} not found in the array after ${comparisons} comparisons.`);
  };

  const startSearch = async () => {
    if (target === null) {
      updateStep('Please provide a target value to search for');
      return;
    }
    
    setSearching(true);
    setFound(null);
    setCurrentIndex(null);
    setSearchBounds(null);
    setComparisonCount(0);
    
    switch (algorithm) {
      case 'linear':
        await linearSearch();
        break;
      case 'binary':
        await binarySearch();
        break;
    }
    
    setSearching(false);
  };

  const stopSearch = () => {
    setSearching(false);
    setCurrentIndex(null);
    setSearchBounds(null);
    updateStep('Search paused');
  };

  const getBarColor = (index: number) => {
    if (found === index) return 'bg-green-500';
    if (currentIndex === index) return 'bg-red-500';
    if (searchBounds && (index < searchBounds.left || index > searchBounds.right)) return 'bg-gray-300';
    if (searchBounds && index >= searchBounds.left && index <= searchBounds.right) return 'bg-yellow-400';
    return 'bg-blue-500';
  };

  const maxValue = array.length > 0 ? Math.max(...array) : 100;

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="capitalize">{algorithm} Search Visualization</CardTitle>
        {problemDescription && (
          <p className="text-sm text-gray-600">{problemDescription}</p>
        )}
        <div className="flex flex-wrap gap-2">
          <Button onClick={searching ? stopSearch : startSearch} variant={searching ? "destructive" : "default"}>
            {searching ? <Pause className="h-4 w-4 mr-2" /> : <Play className="h-4 w-4 mr-2" />}
            {searching ? 'Pause' : 'Start Search'}
          </Button>
        </div>
        <div className="flex items-center space-x-4">
          <span className="text-sm font-medium">Speed:</span>
          <Slider
            value={speed}
            onValueChange={setSpeed}
            max={100}
            min={1}
            step={1}
            className="w-32"
          />
        </div>
        
        <div className="flex gap-4 text-sm">
          <div className="bg-blue-50 px-3 py-1 rounded">
            <span className="font-medium">Target:</span> {target ?? 'Not set'}
          </div>
          <div className="bg-green-50 px-3 py-1 rounded">
            <span className="font-medium">Comparisons:</span> {comparisonCount}
          </div>
          <div className="bg-purple-50 px-3 py-1 rounded">
            <span className="font-medium">Array Size:</span> {array.length}
          </div>
        </div>
      </CardHeader>
      <CardContent>
        {currentStep && (
          <div className="mb-4 p-3 bg-yellow-50 border-l-4 border-yellow-400 rounded">
            <p className="text-sm font-medium text-yellow-800">{currentStep}</p>
          </div>
        )}
        
        <div className="flex items-end justify-center space-x-1 h-80 bg-gray-50 p-4 rounded-lg">
          {array.map((value, index) => (
            <div key={index} className="flex flex-col items-center">
              <div
                className={`transition-colors duration-200 ${getBarColor(index)} rounded-t flex items-end justify-center text-white text-xs font-bold pb-1`}
                style={{
                  height: `${(value / maxValue) * 250 + 30}px`,
                  width: `${Math.max(600 / array.length - 2, 15)}px`,
                }}
              >
                {array.length <= 20 && value}
              </div>
              <div className="text-xs mt-1 text-gray-600">{index}</div>
            </div>
          ))}
        </div>
        <div className="mt-4 flex justify-center space-x-6 text-sm">
          <div className="flex items-center">
            <div className="w-4 h-4 bg-blue-500 rounded mr-2"></div>
            <span>Unsearched</span>
          </div>
          <div className="flex items-center">
            <div className="w-4 h-4 bg-red-500 rounded mr-2"></div>
            <span>Current</span>
          </div>
          <div className="flex items-center">
            <div className="w-4 h-4 bg-green-500 rounded mr-2"></div>
            <span>Found</span>
          </div>
          {algorithm === 'binary' && (
            <>
              <div className="flex items-center">
                <div className="w-4 h-4 bg-yellow-400 rounded mr-2"></div>
                <span>Search Range</span>
              </div>
              <div className="flex items-center">
                <div className="w-4 h-4 bg-gray-300 rounded mr-2"></div>
                <span>Eliminated</span>
              </div>
            </>
          )}
        </div>
      </CardContent>
    </Card>
  );
};

export default SearchVisualizer;

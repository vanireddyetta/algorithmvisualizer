
import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Slider } from '@/components/ui/slider';
import { Play, Pause, RotateCcw, SkipForward } from 'lucide-react';

interface SortingVisualizerProps {
  algorithm: 'bubble' | 'quick' | 'merge';
  inputArray?: number[];
  problemDescription?: string;
  onStepChange?: (step: string) => void;
}

const SortingVisualizer: React.FC<SortingVisualizerProps> = ({ 
  algorithm, 
  inputArray,
  problemDescription,
  onStepChange 
}) => {
  const [array, setArray] = useState<number[]>([]);
  const [sorting, setSorting] = useState(false);
  const [speed, setSpeed] = useState([50]);
  const [comparing, setComparing] = useState<number[]>([]);
  const [sorted, setSorted] = useState<number[]>([]);
  const [currentStep, setCurrentStep] = useState('');
  const [swapCount, setSwapCount] = useState(0);
  const [comparisonCount, setComparisonCount] = useState(0);
  const [pivotIndex, setPivotIndex] = useState<number | null>(null);
  const [partitionBounds, setPartitionBounds] = useState<{left: number, right: number} | null>(null);

  useEffect(() => {
    if (inputArray && inputArray.length > 0) {
      setArray([...inputArray]);
      setComparing([]);
      setSorted([]);
      setSorting(false);
      setSwapCount(0);
      setComparisonCount(0);
      setPivotIndex(null);
      setPartitionBounds(null);
      updateStep('Array loaded and ready to sort');
    } else {
      generateNewArray();
    }
  }, [inputArray]);

  const updateStep = (step: string) => {
    setCurrentStep(step);
    onStepChange?.(step);
  };

  const generateNewArray = () => {
    const newArray = Array.from({ length: 10 }, () => Math.floor(Math.random() * 300) + 10);
    setArray(newArray);
    setComparing([]);
    setSorted([]);
    setSorting(false);
    setSwapCount(0);
    setComparisonCount(0);
    setPivotIndex(null);
    setPartitionBounds(null);
    updateStep('New random array generated');
  };

  const sleep = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

  const bubbleSort = async () => {
    const arr = [...array];
    const n = arr.length;
    let swaps = 0;
    let comparisons = 0;
    
    updateStep('Starting Bubble Sort - comparing adjacent elements');
    
    for (let i = 0; i < n - 1; i++) {
      let swappedInPass = false;
      updateStep(`Pass ${i + 1}: Moving the ${i === 0 ? 'largest' : `${i + 1} largest`} element to its correct position`);
      
      for (let j = 0; j < n - i - 1; j++) {
        if (!sorting) return;
        
        setComparing([j, j + 1]);
        comparisons++;
        setComparisonCount(comparisons);
        updateStep(`Comparing elements at positions ${j} and ${j + 1}: ${arr[j]} vs ${arr[j + 1]}`);
        await sleep(101 - speed[0]);
        
        if (arr[j] > arr[j + 1]) {
          [arr[j], arr[j + 1]] = [arr[j + 1], arr[j]];
          swaps++;
          setSwapCount(swaps);
          swappedInPass = true;
          setArray([...arr]);
          updateStep(`Swapped! ${arr[j + 1]} > ${arr[j]}, so we swap them`);
          await sleep(101 - speed[0]);
        } else {
          updateStep(`No swap needed: ${arr[j]} ≤ ${arr[j + 1]}`);
        }
      }
      setSorted(prev => [...prev, n - 1 - i]);
      updateStep(`Element ${arr[n - 1 - i]} is now in its correct position`);
      
      if (!swappedInPass) {
        updateStep('No swaps in this pass - array is sorted!');
        break;
      }
    }
    setSorted(Array.from({length: n}, (_, i) => i));
    setComparing([]);
    updateStep(`Bubble Sort complete! Used ${swaps} swaps and ${comparisons} comparisons`);
  };

  const quickSort = async () => {
    const arr = [...array];
    let swaps = 0;
    let comparisons = 0;
    
    updateStep('Starting Quick Sort - using divide and conquer approach');

    const quickSortHelper = async (low: number, high: number): Promise<void> => {
      if (low < high && sorting) {
        setPartitionBounds({left: low, right: high});
        updateStep(`Sorting subarray from index ${low} to ${high}`);
        await sleep(101 - speed[0]);

        const pivotIdx = await partition(arr, low, high);
        
        await quickSortHelper(low, pivotIdx - 1);
        await quickSortHelper(pivotIdx + 1, high);
      }
    };

    const partition = async (arr: number[], low: number, high: number): Promise<number> => {
      const pivot = arr[high];
      setPivotIndex(high);
      updateStep(`Choosing pivot: ${pivot} at index ${high}`);
      await sleep(101 - speed[0]);

      let i = low - 1;

      for (let j = low; j < high; j++) {
        if (!sorting) return j;
        
        setComparing([j, high]);
        comparisons++;
        setComparisonCount(comparisons);
        updateStep(`Comparing ${arr[j]} with pivot ${pivot}`);
        await sleep(101 - speed[0]);

        if (arr[j] < pivot) {
          i++;
          if (i !== j) {
            [arr[i], arr[j]] = [arr[j], arr[i]];
            swaps++;
            setSwapCount(swaps);
            setArray([...arr]);
            updateStep(`${arr[j]} < ${pivot}, so swap ${arr[i]} and ${arr[j]}`);
            await sleep(101 - speed[0]);
          }
        }
      }

      [arr[i + 1], arr[high]] = [arr[high], arr[i + 1]];
      swaps++;
      setSwapCount(swaps);
      setArray([...arr]);
      setPivotIndex(null);
      setSorted(prev => [...prev, i + 1]);
      updateStep(`Place pivot ${pivot} in its correct position at index ${i + 1}`);
      await sleep(101 - speed[0]);

      return i + 1;
    };

    await quickSortHelper(0, arr.length - 1);
    setSorted(Array.from({length: arr.length}, (_, i) => i));
    setComparing([]);
    setPivotIndex(null);
    setPartitionBounds(null);
    updateStep(`Quick Sort complete! Used ${swaps} swaps and ${comparisons} comparisons`);
  };

  const mergeSort = async () => {
    const arr = [...array];
    let comparisons = 0;
    
    updateStep('Starting Merge Sort - dividing array into smaller subarrays');

    const mergeSortHelper = async (left: number, right: number): Promise<void> => {
      if (left < right && sorting) {
        const mid = Math.floor((left + right) / 2);
        
        setPartitionBounds({left, right});
        updateStep(`Dividing array from index ${left} to ${right} at middle ${mid}`);
        await sleep(101 - speed[0]);

        await mergeSortHelper(left, mid);
        await mergeSortHelper(mid + 1, right);
        await merge(left, mid, right);
      }
    };

    const merge = async (left: number, mid: number, right: number): Promise<void> => {
      const leftArr = arr.slice(left, mid + 1);
      const rightArr = arr.slice(mid + 1, right + 1);
      
      updateStep(`Merging subarrays [${leftArr.join(', ')}] and [${rightArr.join(', ')}]`);
      await sleep(101 - speed[0]);

      let i = 0, j = 0, k = left;

      while (i < leftArr.length && j < rightArr.length && sorting) {
        setComparing([left + i, mid + 1 + j]);
        comparisons++;
        setComparisonCount(comparisons);
        
        if (leftArr[i] <= rightArr[j]) {
          arr[k] = leftArr[i];
          updateStep(`${leftArr[i]} ≤ ${rightArr[j]}, place ${leftArr[i]} at position ${k}`);
          i++;
        } else {
          arr[k] = rightArr[j];
          updateStep(`${rightArr[j]} < ${leftArr[i]}, place ${rightArr[j]} at position ${k}`);
          j++;
        }
        
        setArray([...arr]);
        k++;
        await sleep(101 - speed[0]);
      }

      while (i < leftArr.length && sorting) {
        arr[k] = leftArr[i];
        setArray([...arr]);
        i++;
        k++;
        await sleep(101 - speed[0]);
      }

      while (j < rightArr.length && sorting) {
        arr[k] = rightArr[j];
        setArray([...arr]);
        j++;
        k++;
        await sleep(101 - speed[0]);
      }

      updateStep(`Merged subarray from ${left} to ${right}`);
    };

    await mergeSortHelper(0, arr.length - 1);
    setSorted(Array.from({length: arr.length}, (_, i) => i));
    setComparing([]);
    setPartitionBounds(null);
    updateStep(`Merge Sort complete! Used ${comparisons} comparisons`);
  };

  const startSorting = async () => {
    setSorting(true);
    setSorted([]);
    setComparing([]);
    setSwapCount(0);
    setComparisonCount(0);
    setPivotIndex(null);
    setPartitionBounds(null);
    
    switch (algorithm) {
      case 'bubble':
        await bubbleSort();
        break;
      case 'quick':
        await quickSort();
        break;
      case 'merge':
        await mergeSort();
        break;
    }
    
    setSorting(false);
  };

  const stopSorting = () => {
    setSorting(false);
    setComparing([]);
    setPivotIndex(null);
    setPartitionBounds(null);
    updateStep('Sorting paused');
  };

  const getBarColor = (index: number) => {
    if (sorted.includes(index)) return 'bg-green-500';
    if (comparing.includes(index)) return 'bg-red-500';
    if (pivotIndex === index) return 'bg-purple-500';
    if (partitionBounds && index >= partitionBounds.left && index <= partitionBounds.right) return 'bg-yellow-400';
    return 'bg-blue-500';
  };

  const maxValue = Math.max(...array);

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="capitalize">{algorithm} Sort Visualization</CardTitle>
        {problemDescription && (
          <p className="text-sm text-gray-600">{problemDescription}</p>
        )}
        <div className="flex flex-wrap gap-2">
          <Button onClick={sorting ? stopSorting : startSorting} variant={sorting ? "destructive" : "default"}>
            {sorting ? <Pause className="h-4 w-4 mr-2" /> : <Play className="h-4 w-4 mr-2" />}
            {sorting ? 'Pause' : 'Start'}
          </Button>
          <Button onClick={generateNewArray} disabled={sorting} variant="outline">
            <RotateCcw className="h-4 w-4 mr-2" />
            Reset
          </Button>
        </div>
        <div className="flex items-center space-x-4">
          <span className="text-sm font-medium">Speed:</span>
          <Slider
            value={speed}
            onValueChange={setSpeed}
            max={100}
            min={1}
            step={1}
            className="w-32"
          />
        </div>
        
        <div className="flex gap-4 text-sm">
          <div className="bg-blue-50 px-3 py-1 rounded">
            <span className="font-medium">Comparisons:</span> {comparisonCount}
          </div>
          <div className="bg-green-50 px-3 py-1 rounded">
            <span className="font-medium">Swaps:</span> {swapCount}
          </div>
          <div className="bg-purple-50 px-3 py-1 rounded">
            <span className="font-medium">Array Size:</span> {array.length}
          </div>
        </div>
      </CardHeader>
      <CardContent>
        {currentStep && (
          <div className="mb-4 p-3 bg-yellow-50 border-l-4 border-yellow-400 rounded">
            <p className="text-sm font-medium text-yellow-800">{currentStep}</p>
          </div>
        )}
        
        <div className="flex items-end justify-center space-x-1 h-80 bg-gray-50 p-4 rounded-lg">
          {array.map((value, index) => (
            <div key={index} className="flex flex-col items-center">
              <div
                className={`transition-colors duration-200 ${getBarColor(index)} rounded-t flex items-end justify-center text-white text-xs font-bold pb-1`}
                style={{
                  height: `${(value / maxValue) * 250 + 30}px`,
                  width: `${Math.max(600 / array.length - 2, 15)}px`,
                }}
              >
                {array.length <= 15 && value}
              </div>
              <div className="text-xs mt-1 text-gray-600">{index}</div>
            </div>
          ))}
        </div>
        <div className="mt-4 flex justify-center space-x-6 text-sm">
          <div className="flex items-center">
            <div className="w-4 h-4 bg-blue-500 rounded mr-2"></div>
            <span>Unsorted</span>
          </div>
          <div className="flex items-center">
            <div className="w-4 h-4 bg-red-500 rounded mr-2"></div>
            <span>Comparing</span>
          </div>
          <div className="flex items-center">
            <div className="w-4 h-4 bg-green-500 rounded mr-2"></div>
            <span>Sorted</span>
          </div>
          {algorithm === 'quick' && (
            <div className="flex items-center">
              <div className="w-4 h-4 bg-purple-500 rounded mr-2"></div>
              <span>Pivot</span>
            </div>
          )}
          {(algorithm === 'quick' || algorithm === 'merge') && (
            <div className="flex items-center">
              <div className="w-4 h-4 bg-yellow-400 rounded mr-2"></div>
              <span>Current Range</span>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
};

export default SortingVisualizer;


import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { RefreshCw, Play } from 'lucide-react';

interface SearchProblemInputProps {
  onSearchSubmit: (array: number[], target: number, problemDescription: string) => void;
  algorithm: string;
}

const SearchProblemInput: React.FC<SearchProblemInputProps> = ({ onSearchSubmit, algorithm }) => {
  const [inputMethod, setInputMethod] = useState<'example' | 'custom'>('example');
  const [customArray, setCustomArray] = useState('');
  const [targetValue, setTargetValue] = useState('');
  const [selectedExample, setSelectedExample] = useState('');

  const examples = {
    linear: [
      {
        name: 'Student IDs',
        array: [12345, 23456, 34567, 45678, 56789, 67890, 78901],
        target: 45678,
        description: 'Find a specific student ID in an unsorted list of student records.'
      },
      {
        name: 'Product Codes',
        array: [101, 205, 309, 156, 278, 434, 189],
        target: 278,
        description: 'Search for a product code in an inventory system.'
      }
    ],
    binary: [
      {
        name: 'Sorted Scores',
        array: [45, 67, 78, 89, 92, 95, 98],
        target: 89,
        description: 'Find a specific test score in a sorted list using binary search.'
      },
      {
        name: 'Sorted Ages',
        array: [18, 22, 25, 30, 35, 40, 45, 50],
        target: 30,
        description: 'Search for a specific age in a sorted demographic dataset.'
      }
    ]
  };

  const currentExamples = examples[algorithm as keyof typeof examples] || examples.linear;

  const generateRandomSearch = () => {
    const array = Array.from({ length: 10 }, () => Math.floor(Math.random() * 100) + 1);
    if (algorithm === 'binary') {
      array.sort((a, b) => a - b);
    }
    const target = array[Math.floor(Math.random() * array.length)];
    const description = `Random search problem - find ${target} in the ${algorithm === 'binary' ? 'sorted' : 'unsorted'} array.`;
    onSearchSubmit(array, target, description);
    setTargetValue(target.toString());
  };

  const handleExampleSelect = (exampleName: string) => {
    setSelectedExample(exampleName);
    const example = currentExamples.find(ex => ex.name === exampleName);
    if (example) {
      onSearchSubmit(example.array, example.target, example.description);
      setTargetValue(example.target.toString());
    }
  };

  const handleCustomSubmit = () => {
    const numbers = customArray
      .split(/[,\s]+/)
      .map(str => parseInt(str.trim()))
      .filter(num => !isNaN(num));
    
    const target = parseInt(targetValue);
    
    if (numbers.length > 0 && !isNaN(target)) {
      let processedArray = [...numbers];
      if (algorithm === 'binary') {
        processedArray.sort((a, b) => a - b);
      }
      const description = `Custom search: Find ${target} in [${processedArray.join(', ')}] using ${algorithm} search.`;
      onSearchSubmit(processedArray, target, description);
    }
  };

  return (
    <Card className="mb-6">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Play className="h-5 w-5" />
          Search Problem Setup
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div className="flex gap-2">
            <Button
              variant={inputMethod === 'example' ? 'default' : 'outline'}
              onClick={() => setInputMethod('example')}
              size="sm"
            >
              Use Example
            </Button>
            <Button
              variant={inputMethod === 'custom' ? 'default' : 'outline'}
              onClick={() => setInputMethod('custom')}
              size="sm"
            >
              Custom Input
            </Button>
            <Button
              variant="outline"
              onClick={generateRandomSearch}
              size="sm"
            >
              <RefreshCw className="h-4 w-4 mr-2" />
              Random
            </Button>
          </div>

          {inputMethod === 'example' ? (
            <div>
              <label className="block text-sm font-medium mb-2">Choose a search example:</label>
              <Select value={selectedExample} onValueChange={handleExampleSelect}>
                <SelectTrigger>
                  <SelectValue placeholder="Select a search problem..." />
                </SelectTrigger>
                <SelectContent>
                  {currentExamples.map((example) => (
                    <SelectItem key={example.name} value={example.name}>
                      {example.name} - Find {example.target} in [{example.array.join(', ')}]
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          ) : (
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-2">
                  Enter array (comma or space separated):
                </label>
                <Textarea
                  value={customArray}
                  onChange={(e) => setCustomArray(e.target.value)}
                  placeholder="e.g., 12, 34, 56, 78, 90"
                  className="mb-2"
                />
              </div>
              <div>
                <label className="block text-sm font-medium mb-2">
                  Target value to search for:
                </label>
                <Input
                  type="number"
                  value={targetValue}
                  onChange={(e) => setTargetValue(e.target.value)}
                  placeholder="e.g., 56"
                  className="mb-2"
                />
              </div>
              <Button 
                onClick={handleCustomSubmit} 
                disabled={!customArray.trim() || !targetValue.trim()}
              >
                Start Search
              </Button>
              {algorithm === 'binary' && (
                <p className="text-sm text-yellow-600">
                  Note: Array will be automatically sorted for binary search
                </p>
              )}
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
};

export default SearchProblemInput;
